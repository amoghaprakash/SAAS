package com.alpha.householdrental.dao;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.alpha.householdrental.model.Rating;

public interface RatingRepository extends MongoRepository<Rating, String> {
	
	@Query("{ 'itemId' : ?0 }")
	public List<Rating> findRatingByItemId(String itemId);
	
	@Query("{ 'itemId' : ?0 , 'userName' :  ?1  }")
	public Rating findrating(String itemId, String userName);

}
