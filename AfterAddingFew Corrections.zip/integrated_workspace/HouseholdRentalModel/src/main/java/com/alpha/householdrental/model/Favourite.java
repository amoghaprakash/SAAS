package com.alpha.householdrental.model;

import java.util.List;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "_Favourite")
public class Favourite {
	@Id
	public ObjectId _id;
	private List<String> itemIDs;
	private String userName;
	
	public Favourite(ObjectId _id, String userName, List<String> itemIDs) {
		super();
		this._id = _id;
		this.itemIDs= itemIDs;
		this.userName = userName;
	}

	public String get_id() {
		return _id.toHexString();
	}

	public List<String> getItemIDs() {
		return itemIDs;
	}
	public void setItemIDs(List<String> itemIDs) {
		this.itemIDs = itemIDs;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
}
