package com.alpha.householdrental.model;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "_Cart")
public class Cart {

	@Id
	private ObjectId _id;
	private String itemId;
	
	private String itemImage;
	private String itemName;
	private String itemOwnerName;
	private String itemOwnerAddress;
	private String userName;
	private int pricePerDay;
	private String fromDate;
	private String toDate;
	private int numOfDaysRented;
	private int totalCost;
	
	public Cart()  {
		
	}
	
	public Cart(ObjectId _id, String itemId, String itemImage, String itemName, String itemOwnerName, String itemOwnerAddress,
			String userName, int pricePerDay, String fromDate, String toDate, int numOfDaysRented, int totalCost) {
		super();
		this._id = _id;
		this.itemId = itemId;
		this.itemImage = itemImage;
		this.itemName = itemName;
		this.itemOwnerName = itemOwnerName;
		this.itemOwnerAddress = itemOwnerAddress;
		this.userName = userName;
		this.pricePerDay = pricePerDay;
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.numOfDaysRented = numOfDaysRented;
		this.totalCost = totalCost;
	}

	public String get_id() {
		return _id.toHexString();
	}

	public void set_id(ObjectId _id) {
		this._id = _id;
	}

	public String get_itemId() {
		return itemId;
	}

	public void set_itemId(String itemId) {
		this.itemId = itemId;
	}

	public String getItemImage() {
		return itemImage;
	}

	public void setItemImage(String itemImage) {
		this.itemImage = itemImage;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getItemOwnerName() {
		return itemOwnerName;
	}

	public void setItemOwnerName(String itemOwnerName) {
		this.itemOwnerName = itemOwnerName;
	}

	public String getItemOwnerAddress() {
		return itemOwnerAddress;
	}

	public void setItemOwnerAddress(String itemOwnerAddress) {
		this.itemOwnerAddress = itemOwnerAddress;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public int getPricePerDay() {
		return pricePerDay;
	}

	public void setPricePerDay(int pricePerDay) {
		this.pricePerDay = pricePerDay;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public int getNumOfDaysRented() {
		return numOfDaysRented;
	}

	public void setNumOfDaysRented(int numOfDaysRented) {
		this.numOfDaysRented = numOfDaysRented;
	}

	public int getTotalCost() {
		return totalCost;
	}

	public void setTotalCost(int totalCost) {
		this.totalCost = totalCost;
	}
	
	
	
}
