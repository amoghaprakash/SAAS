package com.alpha.householdrental.model;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "_Ratings")
public class Rating {

    private String userName;
    private String comments;
    private int rating;
    private String itemId;
    private String firstName;
    
    public Rating( String userName, String comments, int rating, String itemId, String firstName) {
		super();
		this.userName = userName;
		this.comments = comments;
		this.rating = rating;
		this.itemId = itemId;
		this.firstName = firstName;
	}
    
    public Rating() {
		// TODO Auto-generated constructor stub
	}

	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public String getItemId() {
		return itemId;
	}
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

}
