package com.alpha.householdrental.dao;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.DeleteQuery;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.alpha.householdrental.model.Cart;

public interface CartRepository extends MongoRepository<Cart, String> {
	
	@Query("{ 'userName' : ?0 }")
	public List<Cart> findCartItemsByUsersName(String userName);
	
	@Query("{ 'userName' : ?0 }")
	public boolean insertToOrder(String userName); 
	
	
    @DeleteQuery("{ 'userName' : ?0 }") 
	public boolean findAndRemoveByUserName(String userName);
	
	@DeleteQuery("{ 'itemName' : ?0 ,'userName' : ?1 }")
    //@Query(value="{'itemId' : ?0}", delete = true)
	public void removeItemInCartByItemsId(String itemName, String userName);
	
	@Query("{ 'itemName' : ?0 }")
	public boolean saveToCart(String itemName); 

}
