package com.alpha.householdrental.dao;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.alpha.householdrental.model.User;

public interface UserRepository extends MongoRepository<User, String> {

	@Query("{ 'userName' : ?0 }")
	public User findByUserName(String userName);
}
