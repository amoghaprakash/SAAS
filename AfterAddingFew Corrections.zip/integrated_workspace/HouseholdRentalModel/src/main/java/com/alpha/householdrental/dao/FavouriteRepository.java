package com.alpha.householdrental.dao;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.alpha.householdrental.model.Favourite;

public interface FavouriteRepository extends MongoRepository<Favourite, String> {	
	@Query("{ 'userName' : ?0 }")
	public Favourite getFavoriteByUserName(String userName);
}
