package com.alpha.householdrental.model;


import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "_Orders")
public class Order {
	@Id
	private ObjectId _id;
	
    private String userName;
    private String itemName;
    private String itemOwnerName;
    private String itemOwnerAddress;
    private String fromDate;
    private String toDate;
    private int totalCost;
    public String itemId;
    
    
	public Order(ObjectId _id, String userName, String itemName, String itemOwnerName, String itemOwnerAddress, String fromDate,
			String toDate, int totalCost, String itemId) {
		super();
		this._id = _id;
		this.userName = userName;
		this.itemName = itemName;
		this.itemOwnerName = itemOwnerName;
		this.itemOwnerAddress = itemOwnerAddress;
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.totalCost = totalCost;
		this.itemId = itemId;
	}
	
	public Order() {
		// TODO Auto-generated constructor stub
	}

	public String get_id() {
		return _id.toHexString();
	}
	public void set_id(ObjectId _id) {
		this._id = _id;
	}
	
	public String getItemId() {
		return itemId;
	}
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public void setItemOwnerName(String ownerName) {
		this.itemOwnerName = ownerName;
	}
	public String getItemOwnerName() {
		return itemOwnerName;
	}
	public void setItemOwnerAddress(String ownerAddress) {
		this.itemOwnerAddress = ownerAddress;
	}
	public String getItemOwnerAddress() {
		return itemOwnerAddress;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public int getTotalCost() {
		return totalCost;
	}
	public void setTotalCost(int totalCost) {
		this.totalCost = totalCost;
	}
    
    
	
}
