package com.alpha.householdrental.model;

import java.util.List;

import org.bson.types.Binary;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "_Items")
public class Item {
	@Id
	public ObjectId _id;

	private String itemName;
	private int pricePerDay;
	private String categoryName;
	private String condition;
	private String description;
	private List<Item> items;
	private String imagePath;
	private String image;
	private int rating;
	private String userName;
	
	
	public Item(ObjectId _id,String itemName, int pricePerDay, String categoryName, String condition, String description, String imagePath, String image, int rating, String userName) {
		super();
		this._id = _id;
		this.itemName= itemName;
		this.pricePerDay=pricePerDay;
		this.categoryName=categoryName;
		this.condition = condition;
		this.description = description;
		this.imagePath = imagePath;
		this.image = image;
		this.rating = rating;
		this.userName = userName;

	}
	public Item() {
		// TODO Auto-generated constructor stub
	}
	public String get_id() {
		return _id.toHexString();
	}

	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public int getpricePerDay() {
		return pricePerDay;
	}
	public void setPricePerDay(int pricePerDay) {
		this.pricePerDay = pricePerDay;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	

    public List<Item> getUsers() {
        return items;
    }

    public void setUsers(List<Item> items) {
        this.items = items;
    }
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getImagePath() {
		return imagePath;
	}
	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public String getCondition() {
		return condition;
	}
	public void setCondition(String condition) {
		this.condition = condition;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
}
