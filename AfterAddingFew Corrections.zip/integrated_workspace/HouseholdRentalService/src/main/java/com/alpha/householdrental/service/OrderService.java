package com.alpha.householdrental.service;

import java.util.List;

import org.json.JSONArray;

import com.alpha.householdrental.model.Order;


public interface OrderService {
	public List<Order> getOrderDetails(String userName);
	public List<Order> getOrdersByItemId(String itemId);
	public JSONArray getOrderHistory(String userName);
}
