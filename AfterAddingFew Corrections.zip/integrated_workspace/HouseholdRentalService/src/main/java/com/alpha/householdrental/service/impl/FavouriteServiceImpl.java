package com.alpha.householdrental.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alpha.householdrental.dao.FavouriteRepository;
import com.alpha.householdrental.model.Favourite;
import com.alpha.householdrental.service.FavouriteService;

@Service("favoriteItemService")
public class FavouriteServiceImpl implements FavouriteService {
	
	@Autowired
	FavouriteRepository favouriteRepository;
	
	@Override
	public Favourite getFavoriteByUserName(String userName) throws Exception {
		Favourite favourite = null;
		try {			
			favourite = favouriteRepository.getFavoriteByUserName(userName);
		} catch (Exception e) {
			throw new Exception("Error getting details");
		}

		return favourite;
	}
	
	@Override
	public boolean addToFavorites(String userName, String itemID) throws Exception {
		try {
			Favourite favorite = this.getFavoriteByUserName(userName);
			List<String> itemIDs = favorite.getItemIDs();
			if (itemIDs.contains(itemID)) {
				return true;
			}
			itemIDs.add(itemID);
			favouriteRepository.save(favorite);
		}
		catch (Exception e) {
			System.out.println("Item does not exist");
			List<String> itemIDs = new ArrayList<String>();
			itemIDs.add(itemID);
			Favourite favorites = new Favourite(ObjectId.get(), userName, itemIDs);
			favouriteRepository.save(favorites);			
		}
		return true;
	}
}
