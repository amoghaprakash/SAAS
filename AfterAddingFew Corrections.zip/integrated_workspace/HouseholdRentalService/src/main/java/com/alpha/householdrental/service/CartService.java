package com.alpha.householdrental.service;

import java.util.List;

import org.bson.types.ObjectId;

import com.alpha.householdrental.model.Cart;

public interface CartService {
	
    public List<Cart> getCartDetails(String userName);
    
    public boolean insertToOrder(String userName) throws Exception;
	
    public boolean deleteCartDetails(String userName) throws Exception;
	
	public boolean removeItemInCart(String itemName, String userName) throws Exception;
	
	public boolean insertItemToCart(Cart cart) throws Exception;
	
	
}

