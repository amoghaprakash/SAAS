package com.alpha.householdrental.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alpha.householdrental.dao.ItemRepository;
import com.alpha.householdrental.dao.OrderRepository;
import com.alpha.householdrental.dao.RatingRepository;
import com.alpha.householdrental.model.Item;
import com.alpha.householdrental.model.Order;
import com.alpha.householdrental.model.Rating;
import com.alpha.householdrental.service.OrderService;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

@Service("orderService")
public class OrderServiceImpl implements OrderService{
	@Autowired
	OrderRepository orderRepository;
	
	@Autowired
	ItemRepository itemRepository;
	
	@Autowired
	RatingRepository ratingRepository;
	
	@Override
	public List<Order> getOrderDetails(String userName) {
		
		List<Order> orderDetails = new ArrayList<Order>();
		try {
			
			 DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
		     Date dateobj = new Date(System.currentTimeMillis());
		     String fromDate = df.format(dateobj).toString();
			orderDetails.addAll(orderRepository.findOrderDetailsByUsersName(userName, fromDate));
		}
		catch(Exception e) {
			System.out.println("Unable to find the order details!!");
		}
		return orderDetails;
	}
	
	@Override
	public List<Order> getOrdersByItemId(String itemId) {
		List<Order> orderDetails = new ArrayList<Order>();
		try {
			orderDetails.addAll(orderRepository.findOrdersByItemID(itemId));
		} catch(Exception e) {
			System.out.println("Unable to find the order details!!");
		}
		return orderDetails;
	}

	@Override
	public JSONArray getOrderHistory(String userName) {
		
		List<Order> orderDetails = new ArrayList<Order>();
		JSONArray jsonArr = null;
		try {
			 DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
		     Date dateobj = new Date(System.currentTimeMillis());
		    // String todayDate = df.format(dateobj).toString();
			orderDetails.addAll(orderRepository.findOrderHistoryByUsersName(userName));
			 jsonArr = new JSONArray();
			for(Order order : orderDetails) {
				JSONObject json = new JSONObject();
				Item item = itemRepository.findItem(order.itemId);
				Rating rating = ratingRepository.findrating(order.itemId,userName);
				if(item != null) {
					json.put("itemId", order.itemId);
					json.put("itemName",order.getItemName());
					json.put("fromDate", order.getFromDate());
					json.put("_id", order.get_id());
					json.put("image", item.getImage());
					json.put("ownerName", order.getItemOwnerName());
					json.put("totalCost", order.getTotalCost());
					if(dateobj.after(new Date(order.getToDate()))) {
						if(rating == null) {
							json.put("rating", true);
					     }
						else {
							json.put("rating", false);
						}
					}
					else {
						json.put("rating", false);
					}

					jsonArr.put(json);
				}
			}
		}
		catch(Exception e) {
			System.out.println("Unable to find the order details!!");
		}
		return jsonArr;
		
		
	}
}
