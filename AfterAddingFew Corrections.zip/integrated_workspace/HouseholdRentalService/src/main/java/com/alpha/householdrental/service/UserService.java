package com.alpha.householdrental.service;

import com.alpha.householdrental.model.User;

public interface UserService {
	
	public boolean isUserNamePresent(String userName) throws Exception;
	
	public void insertUserDetails(User user) throws Exception;
	
	public boolean resetPassword(User user)throws Exception;
	
	//public User getPasswordDetails(String userName) throws Exception;

	public boolean isUserAuthentic(String userName, String password) throws Exception;

	public User getUserDetails(String userName) throws Exception ;

	
}
