package com.alpha.householdrental.service;

import java.util.List;


import com.alpha.householdrental.model.Rating;

public interface RatingService {
	
	public void insertRatingDetails(Rating rating) throws Exception;
	
	public void getItemRating(String itemId) throws Exception ;
	
	public void updateItemRating(String itemId, int AverageRating) throws Exception ;
	
	public List<Rating> getReviewDetails(String itemId) throws Exception ;	
}
