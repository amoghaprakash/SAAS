package com.alpha.householdrental.service;

import com.alpha.householdrental.model.Favourite;

public interface FavouriteService {
	
	public Favourite getFavoriteByUserName(String userName) throws Exception;
	
	public boolean addToFavorites(String userName, String itemID) throws Exception;

}
