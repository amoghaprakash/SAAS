package com.alpha.householdrental.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alpha.householdrental.dao.RatingRepository;
import com.alpha.householdrental.model.Rating;
import com.alpha.householdrental.model.Item;
import com.alpha.householdrental.service.RatingService;
import com.alpha.householdrental.dao.ItemRepository;

@Service("ratingService")
public class RatingServiceImpl implements RatingService {
	
	@Autowired
	RatingRepository ratingRepository;
	
	@Autowired
	ItemRepository itemRepository;
	
	@Override
	public void insertRatingDetails(Rating rating) throws Exception {
		try {
			ratingRepository.save(rating);
			getItemRating(rating.getItemId());
		}
		catch (Exception e) {
			throw new Exception("Error in saving rating details due to : " + e.getMessage());
		}
	}
	
	@Override
	public void getItemRating(String itemId) throws Exception {
		try {
			List<Rating> ratingDetails = new ArrayList<Rating>();
			ratingDetails.addAll(ratingRepository.findRatingByItemId(itemId));
			if(ratingDetails != null) {
				int sum = 0;
				int count = ratingDetails.size();
				for(Rating rating : ratingDetails) {
					sum += rating.getRating();
				}
				int AverageRating  = sum / count;
				//ObjectId objectId = new ObjectId(itemId);
				updateItemRating(itemId, AverageRating);
			}
			
		}
		catch (Exception e) {
			throw new Exception("Error in getting data from rating table due to : " + e.getMessage());
		}
	}
	
	@Override
	public void updateItemRating(String itemId, int AverageRating) throws Exception {
		try {
			Item item = itemRepository.findItem(itemId);
			if(item != null) {
				item.setRating(AverageRating);
				itemRepository.save(item);
			}
		}
		catch (Exception e) {
			throw new Exception("Error in updating  item rating in item table details due to : " + e.getMessage());
		}
	
	}
	
	@Override
	public List<Rating> getReviewDetails(String itemId) throws Exception {
		List<Rating> ratingDetails = new ArrayList<Rating>();
		try {
			ratingDetails.addAll(ratingRepository.findRatingByItemId(itemId));
		}
		catch (Exception e) {
			throw new Exception("Error in updating  item rating in item table details due to : " + e.getMessage());
		}
		return ratingDetails;
	}

}
