
package com.alpha.householdrental.controller;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.alpha.householdrental.model.Item;
import com.alpha.householdrental.service.ItemService;

@RunWith(MockitoJUnitRunner.class)
public class ItemControllerTest {
	@InjectMocks
	private ItemController itemCreationController = new ItemController();
	
	@Mock
	private ItemService itemService;
	
	private ModelAndView modelAndView;
	private String item;
	private MultipartFile image;
	
	@Before
	public void setUp() {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("itemName", "Diano");
		jsonObject.put("description", "test item");
		jsonObject.put("price", 10);
		jsonObject.put("category", "appliances");
		jsonObject.put("condition", "New");

		item = jsonObject.toString();
		modelAndView = mock(ModelAndView.class);
	}

	@Test
	public void insertItem_savesSuccessfully_returnsSuccess() throws Exception {
		when(itemService.insertItem(any(Item.class))).thenReturn(true);
		
		String response = itemCreationController.insertItem(image,item, modelAndView);
		
		assertNotNull(response);
		assertTrue(response.contains("Success"));
	}

	@Test
	public void insertItem_itemAlreadyExists_returnsSuccess() throws Exception {
		when(itemService.insertItem(any(Item.class))).thenReturn(false);
		
		String response = itemCreationController.insertItem(image,item, modelAndView);
		
		assertNotNull(response);
		assertTrue(response.contains("Error creating item"));
	}
	/*
	 * @Test(expected = Exception.class) public void
	 * insertItem_errorWhileDeserializing_throwsException() throws Exception {
	 * itemCreationController.insertItem("foobar", modelAndView); }
	 */

	@SuppressWarnings("unchecked")
	@Test(expected = IllegalArgumentException.class)
	public void insertItem_errorWhileSaving_returnsSuccess() throws Exception {
		when(itemService.insertItem(any(Item.class))).thenThrow(IllegalArgumentException.class);
		
		itemCreationController.insertItem(image,item, modelAndView);
	}

}
