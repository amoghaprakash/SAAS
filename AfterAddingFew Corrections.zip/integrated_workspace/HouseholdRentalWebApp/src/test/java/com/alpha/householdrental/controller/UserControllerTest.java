package com.alpha.householdrental.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.servlet.ModelAndView;

import com.alpha.householdrental.model.User;
import com.alpha.householdrental.service.UserService;
import com.google.gson.Gson;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
public class UserControllerTest {
	
	@Mock
	private UserService userService;
	
	@InjectMocks
	private UserController userController;
	
	private String user;
	private JSONObject json;
	
	private final static String TEST_USERNAME = "test@test.com";
	private final static String TEST_PASSWORD = "TEST_PASSWORD";
	private final static String TEST_FIRSTNAME = "TEST_FIRSTNAME";
    private final static String TEST_LASTNAME = "TEST_LASTNAME";
	private final static String TEST_CITY = "TEST_CITY";
	private final static String TEST_STATE = "TEST_STATE";
	private final static String TEST_ADDRESS = "TEST_ADDRESS";
	private final static Integer TEST_ZIPCODE = 12345;
	private final static Integer TEST_PHONENUMBER = 1234567890;
	private final static String TEST_EMAIL = "test@test.com";
	private final static String TEST_SECURITY_QUESTION_FIRST = "TEST_SECURITY_QUESTION_FIRST";
	private final static String TEST_SECURITYQUESTIONSECOND = "TEST_SECURITYQUESTIONSECOND";
	private final static String TEST_SECURITY_ANSWER_FIRST = "TEST_SECURITY_ANSWER_FIRST";
	private final static String TEST_SECURITY_ANSWER_SECOND = "TEST_SECURITY_ANSWER_SECOND";
	
	
	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		
		Map<String,Object> params = new HashMap<String,Object>();
		params.put("userName", TEST_USERNAME);
		params.put("password", TEST_PASSWORD);
		params.put("firstName", TEST_FIRSTNAME);
		params.put("lastName", TEST_LASTNAME);
		params.put("city", TEST_CITY);
		params.put("state", TEST_STATE);
		params.put("address", TEST_ADDRESS);
		params.put("zipCode", TEST_ZIPCODE);
		params.put("phoneNumber", TEST_PHONENUMBER);
		params.put("securityQueFirst", TEST_SECURITY_QUESTION_FIRST);
		params.put("email", TEST_EMAIL);
		params.put("securityQueSecond", TEST_SECURITYQUESTIONSECOND);
		params.put("securityAnsFirst", TEST_SECURITY_ANSWER_FIRST);
		params.put("securityAnsSecond", TEST_SECURITY_ANSWER_SECOND);
		
		user = new Gson().toJson(params);
	}
	
	@Test
	public void validateUser_Test_Positive() throws Exception {
		
		Mockito.when(userService.isUserNamePresent(TEST_USERNAME)).thenReturn(true);
		Mockito.doNothing().when(userService).insertUserDetails(Matchers.any(User.class));
		
		String result =  userController.signUp(user, new ModelAndView());
		JSONObject resultJSON = new JSONObject(result);
		
		json = new JSONObject();
		json.put("response", "Success");
		assertNotNull(result);
		assertEquals((String)json.get("response"), (String)resultJSON.get("response"));
	}

}
