package com.alpha.householdrental.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.bson.BsonBinarySubType;
import org.bson.types.Binary;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.alpha.householdrental.model.Cart;
import com.alpha.householdrental.model.Item;
import com.alpha.householdrental.model.Order;
import com.alpha.householdrental.model.User;
import com.alpha.householdrental.service.CartService;
import com.alpha.householdrental.service.ItemService;
import com.alpha.householdrental.service.OrderService;
import com.alpha.householdrental.service.UserService;
import com.google.gson.Gson;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(tags="This controller is used for Home(Item listing) functionality.")
@Controller
public class ItemController {
	@Autowired
	private ItemService itemService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private CartService cartService;

	@Autowired
	private OrderService orderService;

	
	@ApiOperation(value="Based on Category Name displays item list.")
	@ApiResponses(value= {
		@ApiResponse(code=200, message="JSON response - status of operation", response=String.class)
	})
	
	@RequestMapping(value = "getHomeDetails", method = RequestMethod.GET)
	@ResponseBody
	public List<Item> getHomeDetails(ModelAndView model,
			@ApiParam(value="Category Name", required=true)
			@RequestParam(name = "inputCategoryName") String categoryName) {
		List<Item> items = null;
		try {
			items = itemService.getItemDetails(categoryName);
		}
		catch (Exception e) {
			System.out.println("Error in Login: " + e.getMessage());
		}
		return items;
	}
	
	@RequestMapping(value = "insertItem", method = RequestMethod.POST)
	@ResponseBody
	public String insertItem(@RequestParam("image") MultipartFile image,@RequestParam String item, ModelAndView model, HttpServletRequest request) throws Exception {
		JSONObject json = new JSONObject();
		Item itemObj = new Gson().fromJson(item, Item.class);
		Binary binaryImage = new Binary(BsonBinarySubType.BINARY, image.getBytes());
		itemObj.setImage(Base64.getEncoder().encodeToString(binaryImage.getData()));
		//itemService.saveItem(itemObj);
		Cookie[] cookies = request.getCookies();
		String userName = "";
		if (cookies != null) {
		 for (Cookie cookie : cookies) {
		   if (cookie.getName().equals("email")) {
		     userName = cookie.getValue();
		    }
		  }
		}
		itemObj.setUserName(userName);
		if(!itemService.insertItem(itemObj)) {
			 json.put("response", "Error in saving itemdetails !");
		} 
		else
		{
			json.put("response", "Success");
		}
		return json.toString();
	}
	
	@RequestMapping(value = "itemDisplay", method = RequestMethod.GET)
	@ResponseBody
	public Map<String, Object> itemDisplay(ModelAndView model,
			@RequestParam(name = "itemId") String itemId, HttpServletRequest request) throws Exception {
		try {
			Map<String, Object> result = new HashMap<>();
			Item item = itemService.getItemDetailsFromDB(itemId);
			User owner = userService.getUserDetails(item.getUserName());			

			Cookie[] cookies = request.getCookies();
			String userName = "";
			if (cookies != null) {
			 for (Cookie cookie : cookies) {
			   if (cookie.getName().equals("email")) {
			     userName = cookie.getValue();
			    }
			  }
			}
			List<Cart> cartItems = cartService.getCartDetails(userName);
			boolean isItemInCart = false;
			for (Cart cart : cartItems) {
				String cartItemId = cart.get_itemId();
				if (cartItemId.equalsIgnoreCase(itemId)) {
					isItemInCart = true;
					break;
				}
			}
			
			result.put("item", item);
			result.put("owner", owner);
			result.put("isItemInCart", isItemInCart);
			return result;
		} catch (Exception e) {
			return null;
		}
	}
	
	@RequestMapping(value = "validateItemAvailability", method = RequestMethod.GET)
	@ResponseBody
	public Map<String, List<String>> validateItemAvailability(ModelAndView model,
			@RequestParam(name = "itemId") String itemId,
			@RequestParam(name = "startDate") String startDate,
			@RequestParam(name = "endDate") String endDate,			
			HttpServletRequest request) throws Exception {
		try {
			Map<String, List<String>> result = new HashMap<>();
			List<String> conflictingDurations = new ArrayList<String>();
			//boolean isItemAvailable = true;
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy");
			Date selectedStartDate = simpleDateFormat.parse(startDate);
			Date selectedEndDate = simpleDateFormat.parse(endDate);

			List<Order> orders = orderService.getOrdersByItemId(itemId);
			for (Order order : orders) {
				Date orderStartDate = simpleDateFormat.parse(order.getFromDate());
				Date orderEndDate = simpleDateFormat.parse(order.getToDate());
				if (selectedStartDate.compareTo(orderEndDate) <= 0 && selectedEndDate.compareTo(orderStartDate) >= 0) {
					//isItemAvailable = false;
					conflictingDurations.add(String.format("[%s, %s]", order.getFromDate(), order.getToDate()));
				}
			}
			
			result.put("conflictingDurations", conflictingDurations);

			return result;
		} catch (Exception e) {
			return null;
		}
	}

}
