package com.alpha.householdrental.controller;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.alpha.householdrental.model.Favourite;
import com.alpha.householdrental.model.Item;
import com.alpha.householdrental.service.FavouriteService;
import com.alpha.householdrental.service.ItemService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;

@Api(tags="This controller is used for Home(Item listing) functionality.")
@Controller
public class FavouriteController {

	@Autowired
	private FavouriteService favouriteService;

	@Autowired
	private ItemService itemService;
	
	@RequestMapping(value = "favorites", method = RequestMethod.GET)
	@ResponseBody
	public List<Item> getFavorites(ModelAndView model,
			@ApiParam(value="User Name", required=true)
			@RequestParam(name = "userName") String userName) throws Exception {
		try {
			Favourite favourites = favouriteService.getFavoriteByUserName(userName);
			List<String> itemIDs = favourites.getItemIDs();
			List<Item> items = new ArrayList<Item>();
			for (String itemID : itemIDs) {
				items.add(itemService.getItemDetailsFromDB(itemID));
			}

			return items;
		} catch (Exception e) {
			return null;
		}
	}
	
	@RequestMapping(value = "addToFavorites", method = RequestMethod.POST)
	@ResponseBody
	public String addToFavorites(@RequestParam("userName") String userName, @RequestParam("itemID") String itemID, ModelAndView model) throws Exception {
		JSONObject json = new JSONObject();
		if (!favouriteService.addToFavorites(userName, itemID)) {
			 json.put("response", "Error in saving itemdetails !");
		} else {
			json.put("response", "Success");
		}

		return json.toString();
	}

}
