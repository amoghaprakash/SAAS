package com.alpha.householdrental.controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.alpha.householdrental.model.User;
import com.alpha.householdrental.service.UserService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(tags="This controller is used for Login functionality.")
@Controller
public class LoginController {
	
	@Autowired
	private UserService userService;
	
	@ApiOperation(value="Verifies user credentials and redirects to Home page.")
	@ApiResponses(value= {
		@ApiResponse(code=200, message="JSON response - status of operation", response=String.class)
	})
	
    @RequestMapping(value="login", method=RequestMethod.POST)
    @ResponseBody
    public String login(HttpServletResponse response, ModelAndView model, 
    		@ApiParam(value="Username of the customer", required=true) @RequestParam(name = "inputUserName") String userName,
    		@ApiParam(value="Password of the customer", required=true) @RequestParam(name = "inputPassword") String password) throws Exception {
    	JSONObject json = new JSONObject();
    	try {
    		if(!userService.isUserAuthentic(userName, password)) {
        		json.put("response", "Username or Password is wrong!!");
        		return json.toString();
        	} 
    	}
    	catch (Exception e) {
			System.out.println("Error in Login: " + e.getMessage());
			json.put("response", "Error in Login !");
		}
    	addCookie(userService.getUserDetails(userName), response);
    	json.put("response", "Success");
    	return json.toString();
    }

	private void addCookie(User user, HttpServletResponse response) {
		Cookie cookieFirstName = new Cookie("firstName", user.getFirstName());
		Cookie cookieEmail  = new Cookie("email", user.getEmail());
	    //add cookie to response
	    response.addCookie(cookieFirstName);
	    response.addCookie(cookieEmail);
	}
}
