package com.alpha.householdrental.service;

import javax.servlet.annotation.MultipartConfig;

import com.alpha.householdrental.model.Item;



public interface PhotoService {

	 public String addPhoto(String title, MultipartConfig file);
	 public Item getPhoto(String id);
	
}
