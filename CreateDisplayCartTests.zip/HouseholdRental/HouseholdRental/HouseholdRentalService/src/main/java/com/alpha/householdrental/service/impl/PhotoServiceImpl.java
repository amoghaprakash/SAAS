package com.alpha.householdrental.service.impl;

import javax.servlet.annotation.MultipartConfig;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alpha.householdrental.dao.CartRepository;
import com.alpha.householdrental.dao.PhotoRepository;
import com.alpha.householdrental.model.Cart;
import com.alpha.householdrental.model.Item;
import com.alpha.householdrental.service.CartService;
import com.alpha.householdrental.service.PhotoService;
import com.sun.prism.Image;

@Service("photoService")
public class PhotoServiceImpl implements PhotoService {

	@Autowired
	PhotoRepository photoRepository;

	@Override
	public String addPhoto(String title, MultipartConfig file) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Item getPhoto(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
