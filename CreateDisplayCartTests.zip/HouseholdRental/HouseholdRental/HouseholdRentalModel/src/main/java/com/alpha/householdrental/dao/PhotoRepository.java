package com.alpha.householdrental.dao;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.alpha.householdrental.model.Item;

public interface PhotoRepository extends MongoRepository<Item, String> {

	 
}