package com.alpha.householdrental.model;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "_Cart")
public class Cart {

	@Id
	public ObjectId _id;
	
	private String itemName;
	private int quantity;
	
	
	public Cart(ObjectId _id, String itemName, int quantity) {
		super();
		this._id = _id;
		this.itemName = itemName;
		this.quantity = quantity;
	}


	public ObjectId get_id() {
		return _id;
	}


	public void set_id(ObjectId _id) {
		this._id = _id;
	}
	public String getItemName() {
		return itemName;
	}


	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
}
