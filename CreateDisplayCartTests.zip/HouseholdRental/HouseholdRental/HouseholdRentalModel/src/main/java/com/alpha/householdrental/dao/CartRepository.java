package com.alpha.householdrental.dao;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.alpha.householdrental.model.Cart;

public interface CartRepository extends MongoRepository<Cart, String> {

	@Query("{ 'itemName' : ?0 }")
	public boolean saveToCart(String itemName); 
}