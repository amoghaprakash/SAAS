package com.alpha.householdrental.controller;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.web.servlet.ModelAndView;

import com.alpha.householdrental.model.Item;
import com.alpha.householdrental.service.ItemService;

@RunWith(MockitoJUnitRunner.class)
public class ItemDisplayControllerTest {
	@InjectMocks
	private ItemDisplayController itemDisplayController = new ItemDisplayController();
	
	@Mock
	private ItemService itemService;
	@Mock
	private Item mockItem;

	@Test
	public void itemDisplay_itemExists_returnsItem() throws Exception {
		when(itemService.getItemDetailsFromDB(anyString())).thenReturn(mockItem);
		
		Item item = itemDisplayController.itemDisplay();
		
		assertNotNull(item);
		assertEquals(mockItem, item);
	}

	@Test
	public void itemDisplay_itemDoesNotExists_returnsNull() throws Exception {
		when(itemService.getItemDetailsFromDB(anyString())).thenReturn(null);
		
		Item item = itemDisplayController.itemDisplay();
		
		assertNull(item);
	}

	@SuppressWarnings("unchecked")
	@Test(expected = Exception.class)
	public void itemDisplay_dbTimeout_throwsException() throws Exception {
		when(itemService.getItemDetailsFromDB(anyString())).thenThrow(Exception.class);
		
		itemDisplayController.itemDisplay();
	}

}
