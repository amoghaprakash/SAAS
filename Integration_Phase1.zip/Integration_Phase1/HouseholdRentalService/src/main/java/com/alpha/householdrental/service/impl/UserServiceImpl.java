package com.alpha.householdrental.service.impl;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.alpha.householdrental.dao.UserRepository;
import com.alpha.householdrental.model.User;
import com.alpha.householdrental.service.UserService;

@Service("userService")
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepository userRepository;
	
	
	@Override
	public boolean isUserNamePresent(String userName) throws Exception {
		User user = null;
		try {
			user = userRepository.findByUserName(userName);
		}
		catch (Exception e) {
			System.out.println("findByUserName failed due to" + e.getMessage());
			return false;
		}
		return user != null;
	}
	
	@Override
	public void insertUserDetails(User user) throws Exception {
		try {
			user.set_id(ObjectId.get());
			userRepository.save(user);
		}
		catch (Exception e) {
			throw new Exception("Error in saving user: " + user.toString() + "due to" + e.getMessage());
		}
	}
	
	@Override
	public boolean resetPassword(User user) throws Exception {
		User res = null;
		try {
			String securityAnsFirst = user.getSecurityAnsFirst();
			String securityAnsSecond = user.getSecurityAnsSecond();
			res = userRepository.findByUserName(user.getEmail());
			if(securityAnsFirst.equals(res.getSecurityAnsFirst()) && 
					securityAnsSecond.equals(res.getSecurityAnsSecond()) ) {
				res.setPassword(user.getPassword());
				userRepository.save(res);
			}
			else {
				return false;
			}
		}
		catch (Exception e) {
			throw new Exception("Error in resting the password: " + e.getMessage());
		}
		return true;
	}
	

	@Override
	public User getUserDetails(String userName) throws Exception {
		User user = null;
		try {
			user = userRepository.findByUserName(userName);
		}
		catch (Exception e) {
			System.out.println("User does not exist");
		}
		if(user != null) {
			return user;
		}
		else {
			return null;
		}
	}
	
	@Override
	public boolean isUserAuthentic(String userName, String password)  throws Exception {
		User user;
		try {
			user = userRepository.findByUserName(userName);
		}
		catch (Exception e) {
			System.out.println("User does not exist");
			return false;
		}
		if(user != null) {
			return password.equals(user.getPassword());
		}
		else {
			return false;
		}
	}
	
	/*public User getPasswordDetails(String userName) throws Exception {
		User user = null;
		try {
			user = userRepository.findByUserName(userName);
		}
		catch (Exception e) {
			System.out.println("User does not exist");
		}
		
		return user;
	}*/
}
