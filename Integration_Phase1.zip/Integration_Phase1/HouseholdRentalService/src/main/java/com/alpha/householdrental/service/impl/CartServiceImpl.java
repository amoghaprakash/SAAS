package com.alpha.householdrental.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.alpha.householdrental.service.CartService;

import com.alpha.householdrental.dao.CartRepository;
import com.alpha.householdrental.dao.OrderRepository;
import com.alpha.householdrental.model.Cart;
import com.alpha.householdrental.model.Order;


@Service("cartService")
public class CartServiceImpl implements CartService {
	
	@Autowired
	CartRepository cartRepository;
	
	@Autowired
	OrderRepository orderRepository;
	
	@Override
	public List<Cart> getCartDetails(String userName) {
		
		List<Cart> cartItems = new ArrayList<Cart>();
		try {
			cartItems.addAll(cartRepository.findCartItemsByUsersName(userName));
		}
		catch(Exception e) {
			System.out.println("Items not added to cart");
		}
		return cartItems;
	}
	
	
	@Override
	public boolean insertToOrder(String userName) throws Exception {
		
		List<Cart> cart = new ArrayList<Cart>();
		List<Order> order = new ArrayList<Order>();
		
		try {
		
			cart.addAll(cartRepository.findCartItemsByUsersName(userName)); //get details from cart repo and storing to cart
			if(cart.size() != 0) {
				for(Cart carts : cart ) {
				   Order orders = new Order();
				   orders.setUserName(carts.getUserName());
				   orders.setItemName(carts.getItemName());
                   orders.setItemOwnerName(carts.getItemOwnerName());
                   orders.setItemOwnerAddress(carts.getItemOwnerAddress());
                   orders.setFromDate(carts.getFromDate());
                   orders.setToDate(carts.getToDate());
                   orders.setTotalCost(carts.getTotalCost());
                   orders.setItemId(carts.get_itemId());
                   
                   order.add(orders);
                   removeItemInCart(carts.getItemName(),userName);
				  } 
				
				orderRepository.saveAll(order);
			}
			//deleteCartDetails(userName);
			//if(!deleteCartDetails(userName))
			//return false;
		}	
			
		catch (Exception e) {
			System.out.println("Cart is empty!!");
			throw new Exception("Error in saving cart items ");
		}
		return true;
	}
	
	@Override
	public boolean deleteCartDetails(String userName) throws Exception {
		try {
			
			cartRepository.findAndRemoveByUserName(userName);	
		}
		catch (Exception e) {
			System.out.println("Error in deleting cart items!!");
			throw new Exception("Error in deleting cart items ");
		}
		return true;	
	}
	
	
	
	@Override
	public boolean removeItemInCart(String itemName, String userName) throws Exception{
		
		try {
			cartRepository.removeItemInCartByItemsId(itemName, userName);
		}
		catch (Exception e) {
			System.out.println("Error in deleting item details!!");
			throw new Exception("Error in deleting item in cart ");
		}
		return true;
		
	}
	
	@Override
	public boolean insertItemToCart(Cart cart) throws Exception {
		try {
			//user.set_id(ObjectId.get());
			cartRepository.save(cart);
			
		}
		catch (Exception e) {
			System.out.println("Item does not exist");
			throw new Exception("Error in saving Item ");
		}
		return true;
	}
}
