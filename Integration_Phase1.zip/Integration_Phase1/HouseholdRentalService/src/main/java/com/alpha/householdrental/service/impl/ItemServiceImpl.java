package com.alpha.householdrental.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alpha.householdrental.dao.ItemRepository;
import com.alpha.householdrental.model.Item;
import com.alpha.householdrental.service.ItemService;

@Service("itemService")
public class ItemServiceImpl implements ItemService {
	
	@Autowired
	ItemRepository itemRepository;
	
	@Override
	public List<Item> getItemDetails(String categoryName) {
		
		List<Item> items = new ArrayList<Item>();
		try {
			if(categoryName.equals("All")) {
				items.addAll(itemRepository.findAll());
			}
			else {
				items.addAll(itemRepository.findItemByCategoryname(categoryName));
			}
		}
		catch (Exception e) {
			System.out.println("User does not exist");
		}
		
		return items;
	}
	
	
	
	@Override
	public boolean insertItem(Item item) throws Exception {
		try {
			//user.set_id(ObjectId.get());
			itemRepository.insert(item);
			
		}
		catch (Exception e) {
			System.out.println("Item does not exist");
			throw new Exception("Error in saving Item ");
		}
		return true;
	}
	
	@Override
	public Item getItemDetailsFromDB(String itemId) throws Exception {
		Item item = null;
		try {			
			item = itemRepository.findItem(itemId);
		}
		catch (Exception e) {
			throw new Exception("Error getting details");
		}
		
	return item;
	}
}
