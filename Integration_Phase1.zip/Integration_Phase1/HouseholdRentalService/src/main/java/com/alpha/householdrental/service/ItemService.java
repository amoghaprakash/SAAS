package com.alpha.householdrental.service;
import java.util.List;

import com.alpha.householdrental.model.Item;

public interface ItemService {
	
	public List<Item> getItemDetails(String categoryName);
	
	public boolean insertItem(Item item) throws Exception;
	
	public Item getItemDetailsFromDB(String itemId) throws Exception;

}
