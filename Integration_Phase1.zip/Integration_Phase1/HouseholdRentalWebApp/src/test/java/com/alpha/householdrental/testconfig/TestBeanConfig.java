package com.alpha.householdrental.testconfig;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackages = "com.alpha.householdrental")
public class TestBeanConfig {

}