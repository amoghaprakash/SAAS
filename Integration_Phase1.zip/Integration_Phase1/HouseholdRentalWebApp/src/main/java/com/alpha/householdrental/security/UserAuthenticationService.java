package com.alpha.householdrental.security;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Service;

import com.alpha.householdrental.model.User;
import com.alpha.householdrental.service.UserService;

@Service("userAuthenticationService")
public class UserAuthenticationService implements AuthenticationProvider {

	@Autowired
	UserService userService;

	@Override
	public Authentication authenticate(Authentication auth) throws AuthenticationException {
		String userName = auth.getName();
		String password = auth.getCredentials().toString();
		List<GrantedAuthority> test = new ArrayList<GrantedAuthority>();
		User user;
		try {
			user = userService.getUserDetails(userName);
			System.out.println("User entered details: " + userName + "/" + password);
			System.out.println("System returned details: " + user.getUserName() + "/" + user.getPassword());
			if (user != null && userName.equals(user.getUserName()) && password.equals(user.getPassword())) {
				return new UsernamePasswordAuthenticationToken(userName, password, test);
			} else {
				throw new BadCredentialsException("External system authentication failed");
			}
		} catch (Exception e) {
			throw new BadCredentialsException("External system authentication failed");
		}
	}

	@Override
	public boolean supports(Class<?> auth) {
		return auth.equals(UsernamePasswordAuthenticationToken.class);
	}
}
