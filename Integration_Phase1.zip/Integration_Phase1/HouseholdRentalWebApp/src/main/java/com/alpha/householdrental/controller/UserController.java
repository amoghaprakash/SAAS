package com.alpha.householdrental.controller;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.alpha.householdrental.model.User;
import com.alpha.householdrental.service.UserService;
import com.google.gson.Gson;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(tags="This controller is used for all user functionality.")
@Controller("userController")
public class UserController {

	@Autowired
	private UserService userService;
	
	@ApiOperation(value="If new user then it adds to database.")
	@ApiResponses(value= {
		@ApiResponse(code=200, message="JSON response - status of operation", response=String.class)
	})

	@RequestMapping(value = "signUp", method = RequestMethod.POST)
	@ResponseBody
	public String signUp(@ApiParam(value="user as a json string like firstName: test", required=true)
			@RequestParam String user, 
			ModelAndView model) throws Exception {
		User userObj = new Gson().fromJson(user, User.class);
		JSONObject json = new JSONObject();
		try {
			if (!userService.isUserNamePresent(userObj.getUserName())) {
				userService.insertUserDetails(userObj);
			}
		} catch (Exception e) {
			System.out.println("Error in SignUp: " + e.getMessage());
			json.put("response", "Error in saving userdetails !");
			return json.toString();
		}
		json.put("response", "Success");
		return json.toString();
	}
	
	@RequestMapping(value = "resetPassword", method = RequestMethod.POST)
	@ResponseBody
	public String resetPassword(@RequestParam String user, ModelAndView model) throws Exception {
		User userObj = new Gson().fromJson(user, User.class);
		JSONObject json = new JSONObject();
		try {
			if (!userService.resetPassword(userObj)) {
				json.put("response", "Error in reseting password !");
				return json.toString();
			} 
		}
		catch (Exception e) {
			System.out.println("Error in ResetPassword: " + e.getMessage());
			json.put("response", "Error in reseting the  password !");
			return json.toString();
		}
		json.put("response", "Success");
		return json.toString();
	}
	

	@RequestMapping(value = "getPasswordDetails", method = RequestMethod.GET)
	@ResponseBody
	public User getPasswordDetails(ModelAndView model, @RequestParam(name = "inputUserName") String userName) {
		User user = null;
		try {
			 user = userService.getUserDetails(userName);
		}
		catch (Exception e) {
			System.out.println("Error in ResetPassword: " + e.getMessage());
		}
		return user;
	}

	

}
