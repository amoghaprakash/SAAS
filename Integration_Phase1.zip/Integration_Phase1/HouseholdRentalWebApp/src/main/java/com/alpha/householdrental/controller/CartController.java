package com.alpha.householdrental.controller;


import java.util.Base64;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.bson.BsonBinarySubType;
import org.bson.types.Binary;
import org.bson.types.ObjectId;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.alpha.householdrental.model.Cart;
import com.alpha.householdrental.service.CartService;
import com.google.gson.Gson;


@Controller
public class CartController {
	
	@Autowired
	private CartService cartService;
	
	@RequestMapping(value = "getCartDetails", method = RequestMethod.GET)
	@ResponseBody
	public List<Cart> getCartDetails(HttpServletRequest request) {
		Cookie[] cookies = request.getCookies();
		String userName = "";
		if (cookies != null) {
		 for (Cookie cookie : cookies) {
		   if (cookie.getName().equals("email")) {
		     userName = cookie.getValue();
		    }
		  }
		}
		List<Cart> cart = cartService.getCartDetails(userName);
		return cart;	
		}
	
	@RequestMapping(value = "removeItem", method = RequestMethod.POST)
	@ResponseBody
	public boolean removeItem(@RequestParam(name = "itemName") String itemName, HttpServletRequest request) throws Exception {
		//ObjectId itemId= new ObjectId("5e334ad4d5ded1cc9403e430");
		//String itemName = "5e4207bb3a65c8ea43ac27e0";
		Cookie[] cookies = request.getCookies();
		String userName = "";
		if (cookies != null) {
		 for (Cookie cookie : cookies) {
		   if (cookie.getName().equals("email")) {
		     userName = cookie.getValue();
		    }
		  }
		}
		try {
			cartService.removeItemInCart(itemName, userName);	
		}
		catch (Exception e) {
			System.out.println("Error in deleting item in cart!!");
			throw new Exception("Error in deleting item in cart ");
		}
		return true;
	}
	
	@RequestMapping(value = "confirmAndCheckout", method = RequestMethod.POST)
	@ResponseBody
	public String confirmAndCheckout (ModelAndView model,HttpServletRequest request) throws Exception {
		//to do cookie
		Cookie[] cookies = request.getCookies();
		String userName = "";
		if (cookies != null) {
		 for (Cookie cookie : cookies) {
		   if (cookie.getName().equals("email")) {
		     userName = cookie.getValue();
		    }
		  }
		}
		 boolean orderResponse = cartService.insertToOrder(userName);
		
		 JSONObject json = new JSONObject();
		 if(orderResponse == false) {
			 json.put("response", "Error in saving cartdetails !");
		} 
		else
		{
			json.put("response", "Success");
		}
		return json.toString();
		
	}
	
	@RequestMapping(value = "addtocart", method = RequestMethod.POST)
	@ResponseBody
	public String insertItem(@RequestParam String cart, ModelAndView model,HttpServletRequest request) throws Exception {
		 Cart cartObj = new Gson().fromJson(cart, Cart.class);
		 JSONObject json = new JSONObject();
		 Cookie[] cookies = request.getCookies();
			String userName = "";
			if (cookies != null) {
			 for (Cookie cookie : cookies) {
			   if (cookie.getName().equals("email")) {
			     userName = cookie.getValue();
			    }
			  }
			}
			cartObj.setUserName(userName);
		 if(!cartService.insertItemToCart(cartObj)) {
			 json.put("response", "Error in saving itemdetails !");
		} 
		else
		{
			json.put("response", "Success");
		}
		return json.toString();
	}
}
