package com.alpha.householdrental.controller;

import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alpha.householdrental.model.Order;
import com.alpha.householdrental.service.OrderService;

@Controller
public class OrderController {

	@Autowired
	private OrderService orderService;
	
	
	@RequestMapping(value = "confirmAndCheckout", method = RequestMethod.GET)
	@ResponseBody
	public List<Order> confirmAndCheckout(HttpServletRequest request) {
		Cookie[] cookies = request.getCookies();
		JSONObject json = new JSONObject();
		String userName = "";
		if (cookies != null) {
		 for (Cookie cookie : cookies) {
		   if (cookie.getName().equals("email")) {
		     userName = cookie.getValue();
		    }
		  }
		}
		try {
			List<Order> order = orderService.getOrderDetails(userName);
			return order;
		}
		catch (Exception e) {
			System.out.println("Error in confirmAndCheckout: " + e.getMessage());
			json.put("response", "Error in confirmAndCheckout !");
			return null;
		}
	}
	
	
	@RequestMapping(value = "getOrderHistory", method = RequestMethod.GET)
	@ResponseBody
	public String getOrderHistory(HttpServletRequest request) {
		Cookie[] cookies = request.getCookies();
		JSONObject json = new JSONObject();
		String userName = "";
		if (cookies != null) {
		 for (Cookie cookie : cookies) {
		   if (cookie.getName().equals("email")) {
		     userName = cookie.getValue();
		    }
		  }
		}
		try {
			JSONArray jsonArray = orderService.getOrderHistory(userName);
			if(jsonArray != null) {
				return jsonArray.toString();
			}
			else
				return null;
		}
		catch (Exception e) {
			System.out.println("Error in getOrderHistory: " + e.getMessage());
			json.put("response", "Error in getOrderHistory !");
			return json.toString();
		}
	}
	
}
