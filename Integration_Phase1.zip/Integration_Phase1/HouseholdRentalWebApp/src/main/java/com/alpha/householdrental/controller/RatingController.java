package com.alpha.householdrental.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.alpha.householdrental.model.Rating;
import com.alpha.householdrental.model.User;
import com.alpha.householdrental.service.RatingService;
import com.google.gson.Gson;

@Controller
public class RatingController {
	
	@Autowired
	private RatingService ratingService;
	
	@RequestMapping(value = "addRating", method = RequestMethod.POST)
	@ResponseBody
	public String addRating(@RequestParam String ratingDetails, 
			ModelAndView model, HttpServletRequest request) throws Exception {
		Rating ratingObj = new Gson().fromJson(ratingDetails, Rating.class);
		JSONObject json = new JSONObject();
		Cookie[] cookies = request.getCookies();
		String userName = "";
		String firstName = "";
		if (cookies != null) {
		 for (Cookie cookie : cookies) {
		   if (cookie.getName().equals("email")) {
		     userName = cookie.getValue();
		    }
		   if (cookie.getName().equals("firstName")) {
			   firstName = cookie.getValue();
			 }
		  }
		}
		try {
			ratingObj.setUserName(userName);
			ratingObj.setFirstName(firstName);
			ratingService.insertRatingDetails(ratingObj);
		} 
		catch (Exception e) {
			System.out.println("Error in SignUp: " + e.getMessage());
			json.put("response", "Error in saving rating details !");
			return json.toString();
		}
		json.put("response", "Success");
		return json.toString();
	}
	
	@RequestMapping(value = "getReviews", method = RequestMethod.GET)
	@ResponseBody
	public List<Rating> getReviews(ModelAndView model, @RequestParam(name = "itemId") String itemId) {
		List<Rating> rating = new ArrayList<Rating>();
		try {
			 rating = ratingService.getReviewDetails(itemId);
		}
		catch (Exception e) {
			System.out.println("Error in ResetPassword: " + e.getMessage());
		}
		return rating;
	}

}
