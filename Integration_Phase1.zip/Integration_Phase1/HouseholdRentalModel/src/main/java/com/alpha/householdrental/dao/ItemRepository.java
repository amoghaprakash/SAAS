package com.alpha.householdrental.dao;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.alpha.householdrental.model.Item;

public interface ItemRepository extends MongoRepository<Item, String> {
	
	@Query("{ 'categoryName' : ?0 }")
	public List<Item> findItemByCategoryname(String categoryName);
	
	@Query("{ '_id' : ?0 }")
	public Item findItem(String _id);
	

	@Query("{ 'itemId' : ?0 }")
	public Item getItemDetails(String itemName);
	

}
