package com.alpha.householdrental.dao;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.alpha.householdrental.model.Order;

public interface OrderRepository extends MongoRepository<Order, String> {
	
	@Query("{ 'userName' : ?0 , 'fromDate' : { $gte: ?1 } }")
	public List<Order> findOrderDetailsByUsersName(String userName, String fromDate);
	
	@Query("{ 'userName' : ?0 }")
	public List<Order> findOrderHistoryByUsersName(String userName);

		
}

