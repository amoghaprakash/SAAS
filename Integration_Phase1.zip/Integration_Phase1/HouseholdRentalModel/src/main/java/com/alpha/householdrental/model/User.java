package com.alpha.householdrental.model;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
//import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "_Users")
public class User {
	@Id
	public ObjectId _id;

	private String userName;
	private String password;
	private String firstName;
    private String lastName;
	private String city;
	private String state;
	private String address;
	private Integer zipCode;
	private Long phoneNumber;
	private String email;
	private String securityQueFirst;
	private String securityQueSecond;
	private String securityAnsFirst;
	private String securityAnsSecond;
	
	

	

	public User(ObjectId _id,String userName, String password, String firstName, String lastName, String city,
			String state, String address, Integer zipCode, Long phoneNumber, String email, String securityQueSecond, String securityQueFirst, String securityAnsFirst, String securityAnsSecond) {
		super();
		this._id = _id;
		this.userName = userName;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.city = city;
		this.state = state;
		this.address = address;
		this.zipCode = zipCode;
		this.phoneNumber = phoneNumber;
		this.email = email;
		this.securityQueFirst = securityQueFirst;
		this.securityQueSecond = securityQueSecond;
		this.securityAnsFirst = securityAnsFirst;
		this.securityAnsSecond = securityAnsSecond;
		//this._id = _id;
	}
	
	public User() {
		
	}
	
	public User(String userName, String password) {
		this.userName = userName;
		this.password = password;
	}
	
	public String get_id() {
		return _id.toHexString();
	}
	
	public void set_id(ObjectId _id) {
		this._id = _id; 
	}
	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Integer getZipCode() {
		return zipCode;
	}

	public void setZipCode(Integer zipCode) {
		this.zipCode = zipCode;
	}

	public Long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(Long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	public String getSecurityQueFirst() {
		return securityQueFirst;
	}

	public void setSecurityQueFirst(String securityQueFirst) {
		this.securityQueFirst = securityQueFirst;
	}

	public String getSecurityQueSecond() {
		return securityQueSecond;
	}

	public void setSecurityQueSecond(String securityQueSecond) {
		this.securityQueSecond = securityQueSecond;
	}

	public String getSecurityAnsFirst() {
		return securityAnsFirst;
	}

	public void setSecurityAnsFirst(String securityAnsFirst) {
		this.securityAnsFirst = securityAnsFirst;
	}

	public String getSecurityAnsSecond() {
		return securityAnsSecond;
	}

	public void setSecurityAnsSecond(String securityAnsSecond) {
		this.securityAnsSecond = securityAnsSecond;
	}
	@Override
	public String toString() {
		return String.format("User[userName='%s', password='%s']", userName, password);
	}

}
