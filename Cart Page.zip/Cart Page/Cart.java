package com.alpha.householdrental.model;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "_Cart")
public class Cart {

	@Id
	private ObjectId _id;
	private ObjectId _Items_id;
	
	private String itemImage;
	private String itemName;
	private String ownerName;
	private String userName;
	private int quantity;
	private int pricePerDay;
	private int noOfDays;
	private int totalCost;
	
	public Cart(ObjectId _id, ObjectId _Items_id, String itemImage, String itemName, String ownerName, String userName,
			int quantity, int pricePerDay, int noOfDays, int totalCost) {
		super();
		this._id = _id;
		this._Items_id = _Items_id;
		this.itemImage = itemImage;
		this.itemName = itemName;
		this.ownerName = ownerName;
		this.userName = userName;
		this.quantity = quantity;
		this.pricePerDay = pricePerDay;
		this.noOfDays = noOfDays;
		this.totalCost = totalCost;
	}
	
	
	public ObjectId get_id() {
		return _id;
	}
	public void set_id(ObjectId _id) {
		this._id = _id;
	}
	public ObjectId get_Items_id() {
		return _Items_id;
	}
	public void set_Items_id(ObjectId _Items_id) {
		this._Items_id = _Items_id;
	}
	public String getItemImage() {
		return itemImage;
	}
	public void setItemImage(String itemImage) {
		this.itemImage = itemImage;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getPricePerDay() {
		return pricePerDay;
	}
	public void setPricePerDay(int pricePerDay) {
		this.pricePerDay = pricePerDay;
	}
	public int getNoOfDays() {
		return noOfDays;
	}
	public void setNoOfDays(int noOfDays) {
		this.noOfDays = noOfDays;
	}
	public int getTotalCost() {
		return totalCost;
	}
	public void setTotalCost(int totalCost) {
		this.totalCost = totalCost;
	}
	
	
	
	
	
}