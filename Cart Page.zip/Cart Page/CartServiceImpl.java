package com.alpha.householdrental.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.alpha.householdrental.service.CartService;

import com.alpha.householdrental.dao.CartRepository;
import com.alpha.householdrental.model.Cart;
import com.alpha.householdrental.model.Order;


@Service("cartService")
public class CartServiceImpl implements CartService {
	
	@Autowired
	CartRepository cartRepository;
	
	
	@Override
	public List<Cart> getCartDetails(String userName) {
		
		List<Cart> cartItems = new ArrayList<Cart>();
		
		try {
			cartItems.addAll(cartRepository.findCartItemsByUsersName(userName));
		}
		catch(Exception e) {
			System.out.println("Items not added to cart");
		}
		
		return cartItems;
		
	}
	
	
	@Override
	public boolean deleteCartDetails(String userName) throws Exception {
		
		Cart cart = null;
		
		try {
			
			cartRepository.deleteById(userName);
			
		}
		catch (Exception e) {
			System.out.println("Error in deleting cart items!!");
			throw new Exception("Error in deleting cart ");
		}
		return true;
		
		
	}
	
	
	
	/*@Override
	public boolean insertToOrder(Order order) throws Exception {
		
		List<Cart> cartItems = new ArrayList<Cart>();
		String userName = null;
		
		
		try {
			cartItems.addAll(cartRepository.findCartItemsByUsersName(userName));
			
			ListIterator<Cart> iterator = cartItems.listIterator();
			while (iterator.hasNext()) { 
				 {
					System.out.println(iterator);
				}
			}
	        
			
			
			//orderItems.addAll(cartRepository.insertToOrderByUserName(userName));
			//orderRepository.saveAll(orderItems);

			
		}
		catch (Exception e) {
			System.out.println("Cart is empty!!");
			throw new Exception("Error in saving cart items ");
		}
		return true;
	}*/
	

}
