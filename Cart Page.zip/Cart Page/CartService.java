package com.alpha.householdrental.service;

import java.util.List;

import com.alpha.householdrental.model.Cart;
import com.alpha.householdrental.model.Order;

public interface CartService {
	
	public List<Cart> getCartDetails(String userName);
	
	public boolean deleteCartDetails(String userName) throws Exception;
	
	//public boolean insertToOrder(Order order) throws Exception;
	
	
}

