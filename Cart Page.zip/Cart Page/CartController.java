package com.alpha.householdrental.controller;

import java.util.ArrayList;
import java.util.List;

import org.bson.types.ObjectId;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.alpha.householdrental.model.Cart;
import com.alpha.householdrental.model.Order;
import com.alpha.householdrental.service.CartService;
import com.google.gson.Gson;

@Controller
public class CartController {
	
	@Autowired
	private CartService cartService;
	
	@RequestMapping(value = "addToCart", method = RequestMethod.GET)
	@ResponseBody
	public List<Cart> addToCart() {
		String userName = "Sravya@test.com";
		List<Cart> cart = cartService.getCartDetails(userName);
		return cart;	
		}
	
	
	@RequestMapping(value = "confirmAndCheckout", method = RequestMethod.DELETE)
	@ResponseBody
	public boolean confirmAndCheckout() throws Exception {
		
		String userName = "Sravya@test.com"; 
		//cartService.deleteCartDetails(userName)
    try {
			
    	cartService.deleteCartDetails(userName);
			
		}
		catch (Exception e) {
			System.out.println("Error in deleting cart items!!");
			throw new Exception("Error in deleting cart ");
		}
		return true;
			 
		
		
	}
	
	
	
	
	
	/*@RequestMapping(value = "confirmAndCheckout1", method = RequestMethod.POST)
	@ResponseBody
	public String confirmAndCheckout1 (@RequestParam String order, ModelAndView model) throws Exception {
		 Order orderObj = new Gson().fromJson(order, Order.class);
		 JSONObject json = new JSONObject();
		 if(!cartService.insertToOrder(orderObj)) {
			 json.put("response", "Error in saving cartdetails !");
		} 
		else
		{
			json.put("response", "Success");
		}
		return json.toString();
	}*/
	
	
	
	
}
