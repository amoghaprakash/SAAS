package com.alpha.householdrental.service;

import com.alpha.householdrental.model.Item;

public interface ItemService {

	public boolean insertItem(Item item) throws Exception;
	
	public Item getItemDetailsFromDB(String itemName) throws Exception;
	
}
