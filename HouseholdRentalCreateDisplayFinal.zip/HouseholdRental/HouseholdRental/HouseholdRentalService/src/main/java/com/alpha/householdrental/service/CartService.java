package com.alpha.householdrental.service;

import com.alpha.householdrental.model.Cart;


public interface CartService {

	//public boolean isDetailsEmpty(String itemName,String description,int price,String category);
	
	public boolean insertItemToCart(Cart cart) throws Exception;
	
	
}