package com.alpha.householdrental.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.alpha.householdrental.service.UserService;

@Controller
public class LoginController {
	
	@Autowired
	private UserService userService;
	
    @RequestMapping("login")
    public ModelAndView login(ModelAndView model, 
    		@RequestParam(name = "username") String userName,
    		@RequestParam(name = "password") String password) {
    	if(userService.isUserAuthentic(userName, password)) {
    		model.setViewName("listing");
    	} else {
    		model.setViewName("login");
    	}
    	return model;
    }
}
