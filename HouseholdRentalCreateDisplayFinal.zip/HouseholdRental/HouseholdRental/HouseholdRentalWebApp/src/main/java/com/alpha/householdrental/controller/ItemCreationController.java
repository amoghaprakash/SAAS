package com.alpha.householdrental.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.alpha.householdrental.model.Item;
import com.alpha.householdrental.service.ItemService;
import com.alpha.householdrental.service.UserService;

import com.google.gson.Gson;
import org.json.JSONObject;

@Controller
public class ItemCreationController {
	
	@Autowired
	private ItemService itemService;
	
	@RequestMapping(value = "insertItem", method = RequestMethod.POST)
	@ResponseBody
	public String insertItem(@RequestParam String item, ModelAndView model) throws Exception {
		 Item itemObj = new Gson().fromJson(item, Item.class);
		 JSONObject json = new JSONObject();
		 if(!itemService.insertItem(itemObj)) {
			 json.put("response", "Error in saving itemdetails !");
		} 
		else
		{
			json.put("response", "Success");
		}
		return json.toString();
	}


}