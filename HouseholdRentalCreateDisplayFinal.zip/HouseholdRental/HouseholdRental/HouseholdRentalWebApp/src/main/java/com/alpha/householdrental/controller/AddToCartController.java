package com.alpha.householdrental.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.alpha.householdrental.model.Cart;
import com.alpha.householdrental.service.CartService;

import com.google.gson.Gson;
import org.json.JSONObject;

@Controller
public class AddToCartController {
	
	@Autowired
	private CartService cartService;
	
	@RequestMapping(value = "addToCart", method = RequestMethod.POST)
	@ResponseBody
	public String insertItem(@RequestParam String cart, ModelAndView model) throws Exception {
		 Cart cartObj = new Gson().fromJson(cart, Cart.class);
		 JSONObject json = new JSONObject();
		 if(!cartService.insertItemToCart(cartObj)) {
			 json.put("response", "Error in saving itemdetails !");
		} 
		else
		{
			json.put("response", "Success");
		}
		return json.toString();
	}


}