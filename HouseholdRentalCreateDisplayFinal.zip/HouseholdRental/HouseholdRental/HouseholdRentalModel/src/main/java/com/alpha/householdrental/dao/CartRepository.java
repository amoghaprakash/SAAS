package com.alpha.householdrental.dao;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.alpha.householdrental.model.Item;

public interface CartRepository extends MongoRepository<Item, String> {

	@Query("{ 'itemName' : ?0 }")
	public boolean saveToCart(String itemName); 
}