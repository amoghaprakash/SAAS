package com.alpha.householdrental.dao;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.alpha.householdrental.model.Item;

public interface ItemRepository extends MongoRepository<Item, String> {

	@Query("{ 'itemName' : ?0 }")
	public boolean insertItem(String itemName);  // use item name and insert all the details into the database
	
	@Query("{ 'itemName' : ?0 }")
	public Item getItemDetails(String itemName);
	
	
}
