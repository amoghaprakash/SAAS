package com.alpha.householdrental.model;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "_Items")
public class Item {

	@Id
	public ObjectId _id;
	

	private String itemName;
	private String description;
	private String condition;
	private int pricePerDay;
	private String categoryName;
	private String imagePath;
	private int rating;
	private ObjectId _Users_id;
	
	
	public Item(ObjectId _id, String itemName, String description, String condition, int pricePerDay,
			String categoryName, String imagePath, int rating, ObjectId _Users_id) {
		super();
		this._id = _id;
		this.itemName = itemName;
		this.description = description;
		this.condition = condition;
		this.pricePerDay = pricePerDay;
		this.categoryName = categoryName;
		this.imagePath = imagePath;
		this.rating = rating;
		this._Users_id = _Users_id;
	}




	public String getItemName() {
		return itemName;
	}




	public void setItemName(String itemName) {
		this.itemName = itemName;
	}




	public String getDescription() {
		return description;
	}




	public void setDescription(String description) {
		this.description = description;
	}




	public String getCondition() {
		return condition;
	}




	public void setCondition(String condition) {
		this.condition = condition;
	}




	public int getPricePerDay() {
		return pricePerDay;
	}




	public void setPricePerDay(int pricePerDay) {
		this.pricePerDay = pricePerDay;
	}




	public String getCategoryName() {
		return categoryName;
	}




	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}




	public String getImagePath() {
		return imagePath;
	}




	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}




	public int getRating() {
		return rating;
	}




	public void setRating(int rating) {
		this.rating = rating;
	}




	public ObjectId get_Users_id() {
		return _Users_id;
	}




	public void set_Users_id(ObjectId _Users_id) {
		this._Users_id = _Users_id;
	}




	public void set_id(ObjectId _id) {
		this._id = _id;
	}




	public ObjectId get_id() {
		return _id;
	}

}
