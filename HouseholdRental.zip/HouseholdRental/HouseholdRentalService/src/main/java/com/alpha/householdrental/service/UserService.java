package com.alpha.householdrental.service;

public interface UserService {

	public boolean isUserAuthentic(String userName, String password);
	
}
