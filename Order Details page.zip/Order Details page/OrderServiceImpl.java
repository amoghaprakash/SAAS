package com.alpha.householdrental.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alpha.householdrental.dao.OrderRepository;
import com.alpha.householdrental.model.Order;

import com.alpha.householdrental.service.OrderService;

@Service("orderService")
public class OrderServiceImpl implements OrderService{
	
	@Autowired
	OrderRepository orderRepository;
	
	
	
	@Override
	public List<Order> getOrderDetails(String userName) {
		
		List<Order> orderDetails = new ArrayList<Order>();
		try {
			orderDetails.addAll(orderRepository.findOrderDetailsByUsersName(userName));
		}
		catch(Exception e) {
			System.out.println("Unable to find the order details!!");
		}
		return orderDetails;
		
		
	}
}
