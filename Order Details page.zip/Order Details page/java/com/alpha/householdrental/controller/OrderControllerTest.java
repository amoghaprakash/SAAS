package com.alpha.householdrental.controller;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.alpha.householdrental.model.Order;
//import com.alpha.householdrental.service.OrderService;

public class OrderControllerTest {
	
	//@Mock
	//private OrderService orderService;
	
	@Autowired( required = true )
	private OrderController orderController;
	

	@Test
	public void confirmAndCheckout_Test() {
		
		List<Order> result = orderController.confirmAndCheckout();
		assertNotNull(result);
		assertTrue(result.size() > 0);
	
	}

}

