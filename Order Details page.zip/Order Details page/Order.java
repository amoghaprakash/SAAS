package com.alpha.householdrental.model;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "_Orders")
public class Order {
	@Id
	private ObjectId _id;
	
    private String userName;
    private String itemName;
    private String ownerName;
    private String ownerAddress;
    private String fromDate;
    private String toDate;
    private int totalCost;
    
    
	public Order(ObjectId _id, String userName, String itemName, String ownerName, String ownerAddress, String fromDate,
			String toDate, int totalCost) {
		super();
		this._id = _id;
		this.userName = userName;
		this.itemName = itemName;
		this.ownerName = ownerName;
		this.ownerAddress = ownerAddress;
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.totalCost = totalCost;
	}
	
	public ObjectId get_id() {
		return _id;
	}
	public void set_id(ObjectId _id) {
		this._id = _id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public String getOwnerAddress() {
		return ownerAddress;
	}
	public void setOwnerAddress(String ownerAddress) {
		this.ownerAddress = ownerAddress;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public int getTotalCost() {
		return totalCost;
	}
	public void setTotalCost(int totalCost) {
		this.totalCost = totalCost;
	}
    
    
	
}
