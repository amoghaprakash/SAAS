package com.alpha.householdrental.controller;

import java.util.List;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.alpha.householdrental.model.Order;
import com.alpha.householdrental.service.OrderService;
import com.google.gson.Gson;

@Controller
public class OrderController {

	@Autowired
	private OrderService orderService;
	
	
	@RequestMapping(value = "confirmAndCheckout", method = RequestMethod.GET)
	@ResponseBody
	public List<Order> confirmAndCheckout() {
		String userName = "Sravya@test.com";
		List<Order> order = orderService.getOrderDetails(userName);
		return order;
	}
	
	
}
