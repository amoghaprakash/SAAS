package com.alpha.householdrental.service;

import java.util.List;

import com.alpha.householdrental.model.Order;


public interface OrderService {
	
	public List<Order> getOrderDetails(String userName);

}
